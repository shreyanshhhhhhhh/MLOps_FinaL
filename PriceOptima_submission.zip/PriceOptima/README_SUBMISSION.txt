PriceOptima submission pack

Open these first
  docs/PriceOptima_Report.pdf          laboratory report (aim, objectives, workflow, diagrams)
  docs/PriceOptima_Presentation.pptx   slide deck, 14 slides
  README.md                            how to run the project

This folder is the project code. It includes the raw CSV, the trained model files,
the metric plots, and the local DVC remote in dvc-storage/.

It does not include the Python virtual environment, the local MLflow store, or any
AWS keys. Create the environment on your machine:

  py -m venv .venv
  .venv\Scripts\activate
  pip install -r requirements.txt
  dvc pull
  pytest

API without Docker:

  pip install -r requirements-serve.txt
  python -m uvicorn app.main:app --host 127.0.0.1 --port 8000

Then open http://127.0.0.1:8000/docs
